#!/bin/bash

for f in *; do
  if [ -f "$f" ]; then
    echo -n "$f"
    cat "$f" | wc -wl
  fi
done
