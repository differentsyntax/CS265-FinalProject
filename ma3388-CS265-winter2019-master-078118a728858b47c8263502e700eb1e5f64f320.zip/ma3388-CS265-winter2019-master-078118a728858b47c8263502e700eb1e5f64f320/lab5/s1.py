#!/usr/bin/env python2
import sys

filename = sys.argv[1]
sum = 0

f = open(filename, 'r')
for line in f:
    line.strip()
    arr = line.split(",")
    name = arr[0]
    for i in range(1, len(arr)):
        sum = sum + int(arr[i])

    avg = sum/(len(arr)-1)

    print name + "\t", avg

    sum = 0

