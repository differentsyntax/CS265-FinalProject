#!/usr/bin/env python2

import sys

ids = []
data = {}

if(len(sys.argv) == 1):
    for line in sys.stdin:
        line.strip()
        arr = line.split(" ", 1)
        ID = int(arr[0])
        name = arr[1]
        ids.append(ID)
        data[ID] = name

else:
    filename = sys.argv[1]
    f = open(filename, 'r')
    for line in f:
        line.strip()
        arr = line.split(" ", 1)
        ID = int(arr[0])
        name = arr[1]
        ids.append(ID)
        data[ID] = name
    
ids.sort()
for i in range(0, len(ids)):
    print ids[i], "\t" + data[ids[i]]
