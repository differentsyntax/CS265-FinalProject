class Assignment:

    def infix2postfix():

        infix = "13 + 23 - 42 * 2"
    
        eq = infix.split()

        op = []
        req = []
        operators = {"+": 1, "-": 1, "*": 2, "/": 2, "%": 3, "(": 4, ")":0}
        top = 0
        l = 0
        maxeq = 0
        c = 0
        c2 = 0

        for i in range(0,len(eq)):
        
            if(eq[i].isdigit()):
                req.append(eq[i])
            else:
                if eq[i] == '(':
                    c2 = c2 + 1
                    t = i + 1
                    op2 = []
                    while eq[t] != ')':
                        if(eq[t].isdigit()):
                            req.append(eq[t])
                        else:
                            if len(op2) != 0:
                                maxx = operators[eq[t]]
                                maxeq = eq[t]
                                for k in range(0, len(op2)):
                                    if(operators[op2[k]] >=  maxx):
                                        maxx = operators[op2[k]]
                                        maxeq = op2[k]
                                        l = k
                                        c = c + 1

                                if c == 0:
                                    op2.append(eq[t])
                                    top = top + 1
                                else:
                                    req.append(maxeq)
                                    op2[l] = eq[t]
                                    c = 0
                            else:
                                op2.append(eq[t])
                        t = t + 1
                    while(len(op2) != 0):
                        maxx = operators[op2[0]]
                        maxeq = op[0]
                        for k in range(0, len(op2)):
                            if(operators[op2[k]] >= maxx):
                                maxx = operators[op2[k]]
                                maxeq = op2[k]
                                l = k
                        req.append(maxeq)
                        del op2[l]

                    break

                else:
                    if len(op) != 0: 
                        maxx = operators[eq[i]]
                        maxeq = eq[i]
                        for k in range(0, len(op)):
                            if(operators[op[k]] >=  maxx):
                                maxx = operators[op[k]]
                                maxeq = op[k]
                                l = k
                                c = c + 1

                        if c == 0:
                            op.append(eq[i])
                            top = top + 1
                        else:
                            req.append(maxeq)
                            op[l] = eq[i]
                            c = 0
                    else:
                        op.append(eq[i])

    
        if c2 > 0:
        
            while len(op) != 0:
                maxx = operators[op[0]]
                maxeq = op[0]
                for k in range(0, len(op)):
                    if(operators[op[k]] >=  maxx):
                        maxx = operators[op[k]]
                        maxeq = op[k]
                        l = k

                req.append(maxeq)
                del op[l]



            for i in range(t+1, len(eq)):
                if(eq[i].isdigit()):
                    req.append(eq[i])
                else:
                    if eq[i] == '(':
                        c2 = c2 + 1
                        t = i + 1
                        op2 = []
                        while eq[t] != ')':
                            if(eq[t].isdigit()):
                                req.append(eq[t])
                            else:
                                if len(op2) != 0:
                                    maxx = operators[eq[t]]
                                    maxeq = eq[t]
                                    for k in range(0, len(op2)):
                                        if(operators[op2[k]] >=  maxx):
                                            maxx = operators[op2[k]]
                                            maxeq = op2[k]
                                            l = k
                                            c = c + 1

                                    if c == 0:
                                        op2.append(eq[t])
                                        top = top + 1
                                    else:
                                        req.append(maxeq)
                                        op2[l] = eq[t]
                                        c = 0
                                else:
                                    op2.append(eq[t])
                            t = t + 1
                        while(len(op2) != 0):
                            maxx = operators[op2[0]]
                            maxeq = op[0]
                            for k in range(0, len(op2)):
                                if(operators[op2[k]] >= maxx):
                                    maxx = operators[op2[k]]
                                    maxeq = op2[k]
                                    l = k
                            req.append(maxeq)
                            del op2[l]
                    
                        break

                    else:
                        if len(op) != 0:
                            maxx = operators[eq[i]]
                            maxeq = eq[i]
                            for k in range(0, len(op)):
                                if(operators[op[k]] >=  maxx):
                                    maxx = operators[op[k]]
                                    maxeq = op[k]
                                    l = k
                                    c = c + 1

                            if c == 0:
                                op.append(eq[i])
                                top = top + 1
                            else:
                                req.append(maxeq)
                                op[l] = eq[i]
                                c = 0
                        else:
                            op.append(eq[i])

        while len(op) != 0:
            maxx = operators[op[0]]
            maxeq = op[0]
            for k in range(0, len(op)):
                if(operators[op[k]] >=  maxx):
                    maxx = operators[op[k]]
                    maxeq = op[k]
                    l = k

            req.append(maxeq)
            del op[l]
    
        result = ''

        for j in range(0, len(req)):
            result = result + ' ' + req[j]

        print(result)
        return(result)

    def evalPostfix(res):
        
        res.lstrip()
        res.rstrip()
        operands = []
        eq = res.split()
        result = 0
        c = 0
        i = 0

        while(len(eq) != 1):
            if((eq[i]).isdigit()):
                operands.append(eq[i])
            else:
                c = c + 1
                if c == 1:
                    y = operands[len(operands)-1]
                    x = operands[len(operands)-2]
                    result = eval('%d %s %d' % (int(x), eq[i], int(y)))
                    del(eq[eq.index(eq[i])])
                    del(operands[len(operands)-1])
                    del(operands[len(operands)-2])
                    eq[eq.index(y)] = result
                    del(eq[eq.index(x)])
                 
                else:
                    y = result
                    x = operands[len(operands)-2]
                    result = eval('%d %s %d' % (int(x), eq[i], int(y)))
                    del(eq[eq.index(eq[i])])
                    del(operands[len(operands)-1])
                    del(operands[len(operands)-2])
                    eq[eq.index(y)] = result
                    del(eq[eq.index(x)])
                

        print(result)
        return(result)

    if __name__ == "__main__":
        
        result = infix2postfix()
        evalPostfix(result)
